{!! Theme::content() !!}
